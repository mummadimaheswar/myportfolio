export const education = [
  {
    degree: "Bachelor of Technology (B.Tech), Computer Science & Engineering",
    institution: "Nalla Malla Reddy Engineering College",
    year: "2022 - 2026",
  },
  {
    degree: "Senior Secondary Education (XII), Science Stream",
    institution: "Narayana Junior College, Kadapa",
    year: "2022",
    percentage: "90.00%"
  },
  {
    degree: "Secondary Education (X)",
    institution: "Bhashyam High School, Kadapa",
    year: "2020",
    percentage: "98.30%"
  }
];

export const certificates = [
  {
    title: "AI Developer",
    provider: "IBM (Virtual)",
    date: "Aug 2024 - Present",
    details: [
      "Learned to build AI models, work with data, and implement machine learning algorithms using Python",
      "Gained hands-on experience in AI development using industry-standard tools and frameworks"
    ]
  },
  {
    title: "Generative AI with Vertex AI",
    provider: "Google (Virtual)",
    date: "Aug 2024",
    details: [
      "Explored the fundamentals of generative AI, including text and image generation",
      "Learned to implement AI models on Google Cloud's Vertex AI platform"
    ]
  },
  {
    title: "Natural Language Processing (NLP)",
    provider: "Microsoft (Virtual)",
    date: "Jul 2024 - Aug 2024",
    details: [
      "Developed proficiency in NLP techniques and their applications in AI-powered systems",
      "Implemented NLP models for text processing, sentiment analysis, and chatbot development"
    ]
  },
  {
    title: "Computer Vision in Microsoft Azure",
    provider: "Microsoft (Virtual)",
    date: "Jul 2024",
    details: [
      "Worked on computer vision applications using Microsoft Azure AI services",
      "Developed AI models for image classification and object detection"
    ]
  }
];

export const projects = [
  {
    title: "Image Captioning using Gradio",
    date: "Jan 2025",
    details: [
      "Developed an AI-powered image captioning system using deep learning models",
      "Implemented a user-friendly interface with Gradio to generate descriptive captions for images",
      "Improved accessibility, storytelling, and content creation using AI-driven creativity"
    ]
  },
  {
    title: "Simple Chatbot with Open Source LLMs",
    date: "Dec 2024 - Jan 2025",
    details: [
      "Built a chatbot using open-source large language models (LLMs) from Hugging Face",
      "Integrated the chatbot with Python-based NLP pipelines for interactive conversations",
      "Designed a conversational AI interface capable of answering user queries efficiently"
    ]
  },
  {
    title: "Sentiment Analysis",
    date: "Nov 2024",
    details: [
      "Developed a sentiment analysis model to analyze text-based emotions",
      "Applied machine learning techniques to classify sentiments (positive, negative, neutral)",
      "Helped businesses improve customer service and decision-making based on sentiment insights"
    ]
  },
  {
    title: "Emotion Detector",
    date: "Nov 2024",
    details: [
      "Built an AI-powered emotion detection system to analyze user emotions in text data",
      "Applied NLP and deep learning techniques to improve communication and user engagement",
      "Created an intelligent system that can be used for mental health support and user feedback analysis"
    ]
  }
];

export const skills = [
  {
    category: "AI & Machine Learning",
    items: [
      "Deep Learning",
      "Natural Language Processing",
      "Computer Vision",
      "TensorFlow",
      "PyTorch",
      "Scikit-learn",
      "Neural Networks"
    ]
  },
  {
    category: "Programming Languages",
    items: [
      "Python",
      "JavaScript",
      "TypeScript",
      "HTML/CSS",
      "SQL"
    ]
  },
  {
    category: "Cloud Platforms",
    items: [
      "Google Cloud Platform",
      "Microsoft Azure",
      "IBM Cloud",
      "Vertex AI"
    ]
  },
  {
    category: "Tools & Frameworks",
    items: [
      "Jupyter Notebook",
      "Git",
      "Docker",
      "React",
      "Node.js",
      "Pandas",
      "NumPy"
    ]
  }
];