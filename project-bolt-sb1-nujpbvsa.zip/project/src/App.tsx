import React from 'react';
import { Github, Linkedin, Mail, Phone, MapPin, Download, ExternalLink } from 'lucide-react';
import { certificates, projects, education, skills } from './data';

function App() {
  return (
    <div className="min-h-screen bg-gradient-to-br from-gray-900 to-gray-800 text-white">
      {/* Hero Section */}
      <header className="container mx-auto px-4 py-20">
        <div className="max-w-4xl mx-auto text-center">
          <h1 className="text-5xl font-bold mb-4">MUMMADI MAHESWAR REDDY</h1>
          <p className="text-xl text-gray-300 mb-8">Aspiring AI Developer</p>
          <div className="flex flex-wrap justify-center gap-4 text-gray-300">
            <a href="mailto:mummadimahesh12@gmail.com" className="flex items-center gap-2 hover:text-white">
              <Mail size={20} /> mummadimahesh12@gmail.com
            </a>
            <a href="tel:+916303863875" className="flex items-center gap-2 hover:text-white">
              <Phone size={20} /> +91 6303863875
            </a>
            <span className="flex items-center gap-2">
              <MapPin size={20} /> Hyderabad
            </span>
          </div>
        </div>
      </header>

      {/* Career Objective */}
      <section className="bg-gray-800 py-16">
        <div className="container mx-auto px-4">
          <div className="max-w-4xl mx-auto">
            <h2 className="text-3xl font-bold mb-8">Career Objective</h2>
            <p className="text-gray-300 leading-relaxed">
              Artificial Intelligence (AI) is transforming industries, and I am passionate about leveraging AI to solve complex challenges, optimize business processes, and enhance user experiences. My ultimate goal is to become an AI Developer, contributing to the field by designing intelligent systems and implementing innovative solutions.
            </p>
          </div>
        </div>
      </section>

      {/* Skills */}
      <section className="py-16">
        <div className="container mx-auto px-4">
          <div className="max-w-4xl mx-auto">
            <h2 className="text-3xl font-bold mb-8">Technical Skills</h2>
            <div className="grid md:grid-cols-2 gap-6">
              {skills.map((skillGroup, index) => (
                <div key={index} className="bg-gray-800 rounded-lg p-6 transform hover:scale-105 transition-transform">
                  <h3 className="text-xl font-semibold mb-4">{skillGroup.category}</h3>
                  <div className="flex flex-wrap gap-2">
                    {skillGroup.items.map((skill, idx) => (
                      <span
                        key={idx}
                        className="px-3 py-1 bg-gray-700 rounded-full text-sm text-gray-300 hover:bg-gray-600 transition-colors"
                      >
                        {skill}
                      </span>
                    ))}
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      </section>

      {/* Education */}
      <section className="bg-gray-800 py-16">
        <div className="container mx-auto px-4">
          <div className="max-w-4xl mx-auto">
            <h2 className="text-3xl font-bold mb-8">Education</h2>
            <div className="space-y-8">
              {education.map((edu, index) => (
                <div key={index} className="bg-gray-700 rounded-lg p-6 transform hover:scale-105 transition-transform">
                  <h3 className="text-xl font-semibold mb-2">{edu.degree}</h3>
                  <p className="text-gray-300 mb-2">{edu.institution}</p>
                  <p className="text-gray-400">{edu.year}</p>
                  {edu.percentage && (
                    <p className="text-gray-400">Percentage: {edu.percentage}</p>
                  )}
                </div>
              ))}
            </div>
          </div>
        </div>
      </section>

      {/* Certifications */}
      <section className="py-16">
        <div className="container mx-auto px-4">
          <div className="max-w-4xl mx-auto">
            <h2 className="text-3xl font-bold mb-8">Certifications & Training</h2>
            <div className="grid md:grid-cols-2 gap-6">
              {certificates.map((cert, index) => (
                <div key={index} className="bg-gray-800 rounded-lg p-6 transform hover:scale-105 transition-transform">
                  <h3 className="text-xl font-semibold mb-2">{cert.title}</h3>
                  <p className="text-gray-300 mb-2">{cert.provider}</p>
                  <p className="text-gray-400 mb-4">{cert.date}</p>
                  <ul className="text-gray-300 list-disc list-inside">
                    {cert.details.map((detail, idx) => (
                      <li key={idx}>{detail}</li>
                    ))}
                  </ul>
                </div>
              ))}
            </div>
          </div>
        </div>
      </section>

      {/* Projects */}
      <section className="bg-gray-800 py-16">
        <div className="container mx-auto px-4">
          <div className="max-w-4xl mx-auto">
            <h2 className="text-3xl font-bold mb-8">Projects</h2>
            <div className="space-y-8">
              {projects.map((project, index) => (
                <div key={index} className="bg-gray-700 rounded-lg p-6 transform hover:scale-105 transition-transform">
                  <h3 className="text-xl font-semibold mb-2">{project.title}</h3>
                  <p className="text-gray-400 mb-4">{project.date}</p>
                  <ul className="text-gray-300 list-disc list-inside space-y-2">
                    {project.details.map((detail, idx) => (
                      <li key={idx}>{detail}</li>
                    ))}
                  </ul>
                </div>
              ))}
            </div>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="bg-gray-900 py-8">
        <div className="container mx-auto px-4">
          <div className="flex justify-center space-x-6">
            <a href="http://mummadimaheswar.github.io/my-portfolio/" target="_blank" rel="noopener noreferrer" className="text-gray-400 hover:text-white">
              <ExternalLink size={24} />
            </a>
            <a href="#" className="text-gray-400 hover:text-white">
              <Github size={24} />
            </a>
            <a href="#" className="text-gray-400 hover:text-white">
              <Linkedin size={24} />
            </a>
          </div>
        </div>
      </footer>
    </div>
  );
}

export default App;